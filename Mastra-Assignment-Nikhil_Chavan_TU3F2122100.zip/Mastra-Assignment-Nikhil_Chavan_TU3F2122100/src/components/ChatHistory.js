import React from 'react';
import './ChatHistory.css';

export default function ChatHistory({ historyList, onSelect }) {
  return (
    <div className="chat-history">
      {/* <h2>History</h2> */}
      <ul>
        {historyList.map(threadId => (
          <li key={threadId} onClick={() => onSelect(threadId)}>
            {threadId}
          </li>
        ))}
      </ul>
    </div>
  );
}
