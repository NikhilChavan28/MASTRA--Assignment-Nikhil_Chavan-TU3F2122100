import './Message.css';

export default function Message({ role, content }) {
  return (
    <div className={`message ${role}`}>
      <div className="label">{role === 'user' ? 'You' : 'Bot'}</div>
      <div className="bubble">{content}</div>
    </div>
  );
}
